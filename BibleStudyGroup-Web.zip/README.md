BibleStudyGroup-Web

Files:
- index.html   Main website
- manifest.json PWA configuration
- sw.js        Service worker

The uploaded index.html already references manifest.json.
